const User = require('../models/User');
const { logError, logAction } = require('../utils/logger');
const { deleteCachedImage } = require('../utils/cacheManager');

async function cleanupExpiredIdentities() {
    try {
        console.log(`[DB-CLEANUP] بدء تنظيف الهويات المنتهية: ${new Date().toLocaleString()}`);
        const fourteenDaysAgo = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000);
        let cleanedCount = 0;

        const cursor = User.find({}).cursor();
        for await (const user of cursor) {
            const initialLength = user.identities.length;
            user.identities = user.identities.filter(id => {
                const isExpired = new Date(id.expiryDate) < fourteenDaysAgo;
                if (isExpired) {
                    const idx = user.identities.indexOf(id);
                    deleteCachedImage(user.discordId, idx + 1);
                    cleanedCount++;
                }
                return !isExpired;
            });

            if (user.identities.length !== initialLength) {
                await user.save().catch(() => {});
            }
        }

        console.log(`[DB-CLEANUP] تم تنظيف ${cleanedCount} هوية منتهية`);
        await logAction('تنظيف قاعدة البيانات', 'system', `تم حذف ${cleanedCount} هوية منتهية`);
    } catch (error) {
        logError(error, 'cleanupExpiredIdentities');
    }
}

module.exports = { cleanupExpiredIdentities };