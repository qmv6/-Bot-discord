const client = require('../client');
const User   = require('../models/User');
const GuildConfig = require('../models/GuildConfig');
const { logError, logAction } = require('../utils/logger');
const { getRole }             = require('../utils/roleManager');
const { roleToJobsMap }       = require('../constants');

async function cleanupExpiredJobRoles() {
    try {
        console.log(`[AUTO-CLEANUP] بدء تنظيف الرتب المنتهية: ${new Date().toLocaleString()}`);
        const now   = new Date();
        let cleaned = 0;

        for (const guild of client.guilds.cache.values()) {
            const guildConfig = await GuildConfig.findOne({ guildId: guild.id });
            if (!guildConfig) continue;

            const cursor = User.find({}).cursor();
            for await (const user of cursor) {
                try {
                    const member = await guild.members.fetch(user.discordId).catch(() => null);
                    if (!member) continue;

                    const activeJobs = user.identities
                        .filter(id => new Date(id.expiryDate) > now)
                        .map(id => id.job);

                    for (const [roleId, jobs] of Object.entries(roleToJobsMap)) {
                        if (!activeJobs.some(j => jobs.includes(j))) {
                            const role = await getRole(guild, roleId);
                            if (role && role.manageable && member.roles.cache.has(role.id)) {
                                await member.roles.remove(role);
                                cleaned++;
                            }
                        }
                    }
                } catch (e) {}
            }
        }

        console.log(`[AUTO-CLEANUP] تم تنظيف ${cleaned} رتبة`);
        await logAction('تنظيف تلقائي للرتب', 'system', `تم تنظيف ${cleaned} رتبة`);
    } catch (error) {
        logError(error, 'cleanupExpiredJobRoles');
    }
}

module.exports = { cleanupExpiredJobRoles };