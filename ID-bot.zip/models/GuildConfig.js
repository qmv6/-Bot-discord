const mongoose = require('mongoose');

const guildConfigSchema = new mongoose.Schema({
    guildId: { type: String, required: true, unique: true },
    verificationChannelId: { type: String, default: null },
    verifiedRoleId:        { type: String, default: null },
    verificationRoleId:    { type: String, default: null },
    logChannelId:          { type: String, default: null },
    updatedAt:             { type: Date, default: Date.now }
});

module.exports = mongoose.model('GuildConfig', guildConfigSchema);